<?php
// To call this page, in the browser type a route that doesn't exist like:
// http://localhost/test/route

echo 'PAGE NOT FOUND';